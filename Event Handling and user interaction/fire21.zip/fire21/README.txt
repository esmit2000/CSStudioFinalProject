Garden Salads made fresh daily $2.50 plus tax; or for another dollar, let us add chicken salad, tuna, ham or whatever item you want 
and make it a Chef�s Salad.

M&M cookies now accompany our famous Chocolate Chip cookies. Made fresh daily; 3 for a Dollar

