#include <math.h>
#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int x = 1;

    while(x <= 50)
    {
        printf("%i\n", x);
        x += 1;
    }
}