#include <stdio.h>
#include <math.h>
#include <string.h>
#include <cs50.h>
#include <ctype.h>

int main(void)
{
    string a = "a";
    string b = "b";
    printf("%c\n", a[0] + (b[0] - a[0]));
    printf("%c\n", 195);
}