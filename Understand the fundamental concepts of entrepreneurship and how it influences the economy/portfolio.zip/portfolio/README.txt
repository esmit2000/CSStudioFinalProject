A website to be hosted on github sites that will preview and provide links to various programming (and potentiall engineering) projects I have created over the past four years in high school
tools: 
    command for compiling scss to sass IN TERMINAL: 
        node-sass input.scss input.css
    
